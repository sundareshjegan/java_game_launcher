/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gamelauncher;

import javax.swing.JOptionPane;


public class TicTacToe extends javax.swing.JFrame {

    int turn = 2;
    int buttonused[] = {0,0,0,0,0,0,0,0,0};
    int p1won[] = {0,0,0,0,0,0,0,0,0};
    int p2won[] = {0,0,0,0,0,0,0,0,0};
    
    int p1_score = 0;
    int p2_score = 0;
    
    String name1;
    String name2;
    int choose;
    public TicTacToe() 
    {
        
        initComponents();      
        
    }
    public void reset()
    {
        b1.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b2.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b3.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b4.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b5.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b6.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b7.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b8.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b5.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
    }

   public  void showMessage()
    {
        JOptionPane.showMessageDialog(this,"This place is already slelected","Warning",0);
    }
   
   public void showWin(int player)
   {
       if(player == 1)
       {
           JOptionPane.showMessageDialog(this,name1+" won the game");
           p1_score += 1;
       }
       else if(player == 2)
       {
           JOptionPane.showMessageDialog(this,name2+" won the game");
           p2_score +=1;
       }
       
       p1_score_label.setText(""+p1_score);
       p2_score_label.setText(""+p2_score);
   }
   boolean p1won()
   {
       if(p1won[0]==1 && p1won[1]==1 && p1won[2]==1)
       {
           return true;
       }
       if(p1won[3]==1 && p1won[4]==1 && p1won[5]==1)
       {
           return true;
       }
       if(p1won[6]==1 && p1won[7]==1 && p1won[8]==1)
       {
           return true;
       }
       if(p1won[0]==1 && p1won[3]==1 && p1won[6]==1)
       {
           return true;
       }
       if(p1won[1]==1 && p1won[4]==1 && p1won[7]==1)
       {
           return true;
       }
       if(p1won[2]==1 && p1won[5]==1 && p1won[8]==1)
       {
           return true;
       }
       if(p1won[2]==1 && p1won[4]==1 && p1won[6]==1)
       {
           return true;
       }
       if(p1won[0]==1 && p1won[4]==1 && p1won[8]==1)
       {
           return true;
       }
       return false;
       
   }
   boolean p2won()
   {
       if(p2won[0]==1 && p2won[1]==1 && p2won[2]==1)
       {
           return true;
       }
       if(p2won[3]==1 && p2won[4]==1 && p2won[5]==1)
       {
           return true;
       }
       if(p2won[6]==1 && p2won[7]==1 && p2won[8]==1)
       {
           return true;
       }
       if(p2won[0]==1 && p2won[3]==1 && p2won[6]==1)
       {
           return true;
       }
       if(p2won[1]==1 && p2won[4]==1 && p2won[7]==1)
       {
           return true;
       }
       if(p2won[2]==1 && p2won[5]==1 && p2won[8]==1)
       {
           return true;
       }
       if(p2won[2]==1 && p2won[4]==1 && p2won[6]==1)
       {
           return true;
       }
       if(p2won[0]==1 && p2won[4]==1 && p2won[8]==1)
       {
           return true;
       }
       return false;
   }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        p1_name = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        p2_name = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        exit_msg = new javax.swing.JLabel();
        main_panel = new javax.swing.JPanel();
        ttt_panel = new javax.swing.JPanel();
        b1 = new javax.swing.JButton();
        b2 = new javax.swing.JButton();
        b4 = new javax.swing.JButton();
        b5 = new javax.swing.JButton();
        b6 = new javax.swing.JButton();
        b7 = new javax.swing.JButton();
        b9 = new javax.swing.JButton();
        b8 = new javax.swing.JButton();
        b3 = new javax.swing.JButton();
        score_panel = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        p2_score_label = new javax.swing.JLabel();
        name2_label = new javax.swing.JLabel();
        p1_score_label = new javax.swing.JLabel();
        name1_label = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        name2_label1 = new javax.swing.JLabel();
        name1_label1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        play_again_msg = new javax.swing.JLabel();
        reset_msg = new javax.swing.JLabel();
        p1label = new javax.swing.JLabel();
        p2label = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        help_msg = new javax.swing.JLabel();

        setTitle("TIC TAC TOE GAME");
        setResizable(false);

        jPanel4.setBackground(new java.awt.Color(0, 0, 0));

        jPanel3.setBackground(new java.awt.Color(0, 0, 0));

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setAutoscrolls(true);
        jPanel1.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentHidden(java.awt.event.ComponentEvent evt) {
                jPanel1ComponentHidden(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("PLAYER 1 NAME ");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("PLAYER 2 NAME");

        p2_name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p2_nameActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(153, 255, 204));
        jButton3.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jButton3.setText("continue");
        jButton3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(36, 36, 36)
                                .addComponent(p1_name, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(p2_name, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(149, 149, 149)
                        .addComponent(jButton3)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(p1_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(p2_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addComponent(jButton3)
                .addContainerGap())
        );

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/XO/tictactoe_logo.jpg"))); // NOI18N
        jLabel4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jButton4.setBackground(new java.awt.Color(255, 0, 0));
        jButton4.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jButton4.setText("X");
        jButton4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton4MouseExited(evt);
            }
        });
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        exit_msg.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        exit_msg.setForeground(new java.awt.Color(0, 255, 255));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addContainerGap(18, Short.MAX_VALUE)
                        .addComponent(exit_msg, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)))
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(exit_msg, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 42, Short.MAX_VALUE))
        );

        main_panel.setBackground(new java.awt.Color(0, 0, 0));
        main_panel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        ttt_panel.setBackground(new java.awt.Color(255, 255, 255));

        b1.setBackground(new java.awt.Color(0, 0, 0));
        b1.setFont(new java.awt.Font("Times New Roman", 0, 48)); // NOI18N
        b1.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 3, 3, new java.awt.Color(0, 0, 0)));
        b1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        b1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b1ActionPerformed(evt);
            }
        });

        b2.setBackground(new java.awt.Color(0, 0, 0));
        b2.setFont(new java.awt.Font("Times New Roman", 0, 48)); // NOI18N
        b2.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 3, 3, 3, new java.awt.Color(0, 0, 0)));
        b2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        b2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b2ActionPerformed(evt);
            }
        });

        b4.setBackground(new java.awt.Color(0, 0, 0));
        b4.setFont(new java.awt.Font("Times New Roman", 0, 48)); // NOI18N
        b4.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 1, 3, 3, new java.awt.Color(0, 0, 0)));
        b4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        b4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b4ActionPerformed(evt);
            }
        });

        b5.setBackground(new java.awt.Color(0, 0, 0));
        b5.setFont(new java.awt.Font("Times New Roman", 0, 48)); // NOI18N
        b5.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(0, 0, 0)));
        b5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        b5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b5ActionPerformed(evt);
            }
        });

        b6.setBackground(new java.awt.Color(0, 0, 0));
        b6.setFont(new java.awt.Font("Times New Roman", 0, 48)); // NOI18N
        b6.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 1, new java.awt.Color(0, 0, 0)));
        b6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        b6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b6ActionPerformed(evt);
            }
        });

        b7.setBackground(new java.awt.Color(0, 0, 0));
        b7.setFont(new java.awt.Font("Times New Roman", 0, 48)); // NOI18N
        b7.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 1, 1, 3, new java.awt.Color(0, 0, 0)));
        b7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        b7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b7ActionPerformed(evt);
            }
        });

        b9.setBackground(new java.awt.Color(0, 0, 0));
        b9.setFont(new java.awt.Font("Times New Roman", 0, 48)); // NOI18N
        b9.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 1, 1, new java.awt.Color(0, 0, 0)));
        b9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        b9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b9ActionPerformed(evt);
            }
        });

        b8.setBackground(new java.awt.Color(0, 0, 0));
        b8.setFont(new java.awt.Font("Times New Roman", 0, 48)); // NOI18N
        b8.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 1, 3, new java.awt.Color(0, 0, 0)));
        b8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        b8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b8ActionPerformed(evt);
            }
        });

        b3.setBackground(new java.awt.Color(0, 0, 0));
        b3.setFont(new java.awt.Font("Times New Roman", 0, 48)); // NOI18N
        b3.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 3, 3, 1, new java.awt.Color(0, 0, 0)));
        b3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        b3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ttt_panelLayout = new javax.swing.GroupLayout(ttt_panel);
        ttt_panel.setLayout(ttt_panelLayout);
        ttt_panelLayout.setHorizontalGroup(
            ttt_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ttt_panelLayout.createSequentialGroup()
                .addComponent(b1, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(b2, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(b3, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(ttt_panelLayout.createSequentialGroup()
                .addGroup(ttt_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ttt_panelLayout.createSequentialGroup()
                        .addComponent(b4, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b5, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b6, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(ttt_panelLayout.createSequentialGroup()
                        .addComponent(b7, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b8, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b9, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        ttt_panelLayout.setVerticalGroup(
            ttt_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ttt_panelLayout.createSequentialGroup()
                .addGroup(ttt_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(b1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b3, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ttt_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(b4, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b5, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b6, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ttt_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(b7, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b8, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b9, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        score_panel.setBackground(new java.awt.Color(0, 0, 0));
        score_panel.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(153, 153, 0)));

        jButton2.setBackground(new java.awt.Color(153, 255, 153));
        jButton2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jButton2.setText("PLAY AGAIN");
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton2MouseExited(evt);
            }
        });
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(51, 153, 255));
        jButton1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jButton1.setText("RESET");
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton1MouseExited(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        p2_score_label.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        p2_score_label.setForeground(new java.awt.Color(255, 255, 0));
        p2_score_label.setText("0");

        name2_label.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        name2_label.setForeground(new java.awt.Color(0, 255, 204));
        name2_label.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        name2_label.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        p1_score_label.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        p1_score_label.setForeground(new java.awt.Color(255, 255, 51));
        p1_score_label.setText("0");

        name1_label.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        name1_label.setForeground(new java.awt.Color(0, 255, 204));
        name1_label.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        name1_label.setFocusable(false);
        name1_label.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jLabel3.setFont(new java.awt.Font("Sitka Heading", 3, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 51, 0));
        jLabel3.setText("SCORE BOARD");
        jLabel3.setBorder(new javax.swing.border.MatteBorder(null));

        name2_label1.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        name2_label1.setForeground(new java.awt.Color(255, 153, 51));
        name2_label1.setText("SCORE");

        name1_label1.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        name1_label1.setForeground(new java.awt.Color(255, 153, 51));
        name1_label1.setText("SCORE");

        jPanel2.setBackground(new java.awt.Color(255, 255, 102));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 11, Short.MAX_VALUE)
        );

        jPanel5.setBackground(new java.awt.Color(255, 255, 102));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 11, Short.MAX_VALUE)
        );

        jPanel6.setBackground(new java.awt.Color(255, 255, 153));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 11, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        play_again_msg.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        play_again_msg.setForeground(new java.awt.Color(102, 255, 102));
        play_again_msg.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        reset_msg.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        reset_msg.setForeground(new java.awt.Color(102, 255, 102));
        reset_msg.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout score_panelLayout = new javax.swing.GroupLayout(score_panel);
        score_panel.setLayout(score_panelLayout);
        score_panelLayout.setHorizontalGroup(
            score_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(score_panelLayout.createSequentialGroup()
                .addGroup(score_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(name1_label, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(score_panelLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(name1_label1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(score_panelLayout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(p1_score_label, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(score_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(name2_label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, score_panelLayout.createSequentialGroup()
                        .addGroup(score_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(name2_label1, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(p2_score_label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(33, 33, 33))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, score_panelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(90, 90, 90))
            .addGroup(score_panelLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37))
            .addGroup(score_panelLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(play_again_msg, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addComponent(reset_msg, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        score_panelLayout.setVerticalGroup(
            score_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, score_panelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(score_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(score_panelLayout.createSequentialGroup()
                        .addGroup(score_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(name1_label, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(name2_label, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(score_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(name2_label1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(name1_label1, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(score_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p2_score_label, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p1_score_label, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21)
                .addGroup(score_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2)
                    .addComponent(jButton1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(score_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(play_again_msg, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(reset_msg, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(179, 179, 179))
        );

        p1label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        p1label.setForeground(new java.awt.Color(255, 255, 0));

        p2label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        p2label.setForeground(new java.awt.Color(255, 255, 0));

        javax.swing.GroupLayout main_panelLayout = new javax.swing.GroupLayout(main_panel);
        main_panel.setLayout(main_panelLayout);
        main_panelLayout.setHorizontalGroup(
            main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, main_panelLayout.createSequentialGroup()
                .addComponent(ttt_panel, javax.swing.GroupLayout.PREFERRED_SIZE, 325, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(main_panelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                        .addComponent(score_panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29))
                    .addGroup(main_panelLayout.createSequentialGroup()
                        .addGap(61, 61, 61)
                        .addComponent(p1label, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(49, 49, 49)
                        .addComponent(p2label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        main_panelLayout.setVerticalGroup(
            main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, main_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(main_panelLayout.createSequentialGroup()
                        .addGap(0, 11, Short.MAX_VALUE)
                        .addComponent(ttt_panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(main_panelLayout.createSequentialGroup()
                        .addGroup(main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p1label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(p2label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addComponent(score_panel, javax.swing.GroupLayout.PREFERRED_SIZE, 279, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );

        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/help.jpg"))); // NOI18N
        jButton5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton5MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton5MouseExited(evt);
            }
        });
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        help_msg.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        help_msg.setForeground(new java.awt.Color(153, 255, 255));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(help_msg, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(753, 753, 753)
                        .addComponent(jLabel5))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(main_panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(help_msg, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(main_panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(267, 267, 267))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(25, 25, 25))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 563, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void b1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b1ActionPerformed
        if(buttonused[0]==0)
        {
            if(turn%2==0)
            {
                b1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/XO/X Small.jpeg")));
                buttonused[0]=1;
                p1won[0]=1;
            }
            else
            {
                b1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/XO/O small.jpeg")));
                buttonused[0]=1;
                p2won[0]=1;
            }
            turn++;
            if(p1won())
            {
                showWin(1);
                Reset();
            }
            else if(p2won())
            {
                showWin(2);
                Reset();
            }
            
        }
        else
        {
            showMessage();
        }
    }//GEN-LAST:event_b1ActionPerformed

    private void b2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b2ActionPerformed
        if(buttonused[1]==0)
        {
            if(turn%2==0)
            {
                b2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/XO/X Small.jpeg")));
                buttonused[1]=1;
                p1won[1]=1;
            }
            else
            {
                b2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/XO/O small.jpeg")));
                buttonused[1]=1;
                p2won[1]=1;
            }
            turn++;
            if(p1won())
            {
                showWin(1);
                Reset();
            }
            else if(p2won())
            {
                showWin(2);
                Reset();
            }
            
            
        }
        else
        {
            showMessage();
        }
    }//GEN-LAST:event_b2ActionPerformed

    private void b3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b3ActionPerformed
        if(buttonused[2]==0)
        {
            if(turn%2==0)
            {
                b3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/XO/X Small.jpeg")));
                buttonused[2]=1;
                p1won[2]=1;
            }
            else
            {
                b3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/XO/O small.jpeg")));
                buttonused[2]=1;
                p2won[2]=1;
            }
            turn++;
            if(p1won())
            {
                showWin(1);
                Reset();
            }
            else if(p2won())
            {
                showWin(2);
                Reset();
            }
            
        }
        else
        {
            showMessage();
        }
    }//GEN-LAST:event_b3ActionPerformed

    private void b4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b4ActionPerformed
        if(buttonused[3]==0)
        {
            if(turn%2==0)
            {
                b4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/XO/X Small.jpeg")));
                buttonused[3]=1;
                p1won[3]=1;
            }
            else
            {
                b4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/XO/O small.jpeg")));
                buttonused[3]=1;
                p2won[3]=1;
            }
            turn++;
            if(p1won())
            {
                showWin(1);
                Reset();
            }
            else if(p2won())
            {
                showWin(2);
                Reset();
            }
            
        }
        else
        {
            showMessage();
        }
    }//GEN-LAST:event_b4ActionPerformed

    private void b5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b5ActionPerformed
        if(buttonused[4]==0)
        {
            if(turn%2==0)
            {
                b5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/XO/X Small.jpeg")));
                buttonused[4]=1;
                p1won[4]=1;
            }
            else
            {
                b5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/XO/O small.jpeg")));
                buttonused[4]=1;
                p2won[4]=1;
            }
            turn++;
            if(p1won())
            {
                showWin(1);
                Reset();
            }
            else if(p2won())
            {
                showWin(2);
                Reset();
            }
            
        }
        else
        {
            showMessage();
        }
    }//GEN-LAST:event_b5ActionPerformed

    private void b6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b6ActionPerformed
        if(buttonused[5]==0)
        {
            if(turn%2==0)
            {
                b6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/XO/X Small.jpeg")));
                buttonused[5]=1;
                p1won[5]=1;
            }
            else
            {
                b6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/XO/O small.jpeg")));
                buttonused[5]=1;
                p2won[5]=1;
            }
            turn++;
            if(p1won())
            {
                showWin(1);
                Reset();
            }
            else if(p2won())
            {
                showWin(2);
                Reset();
            }
            
            
        }
        else
        {
            showMessage();
        }
    }//GEN-LAST:event_b6ActionPerformed

    private void b7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b7ActionPerformed
        if(buttonused[6]==0)
        {
            if(turn%2==0)
            {
                b7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/XO/X Small.jpeg")));
                buttonused[6]=1;
                p1won[6]=1;
            }
            else
            {
                b7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/XO/O small.jpeg")));
                buttonused[6]=1;
                p2won[6]=1;
            }
            turn++;
            if(p1won())
            {
                showWin(1);
                Reset();
            }
            else if(p2won())
            {
                showWin(2);
                Reset();
            }
            
        }
        else
        {
            showMessage();
        }
    }//GEN-LAST:event_b7ActionPerformed

    private void b8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b8ActionPerformed
        if(buttonused[7]==0)
        {
            if(turn%2==0)
            {
                b8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/XO/X Small.jpeg")));
                buttonused[7]=1;
                p1won[7]=1;
            }
            else
            {
                b8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/XO/O small.jpeg")));
                buttonused[7]=1;
                p2won[7]=1;
            }
            turn++;
            if(p1won())
            {
                showWin(1);
                Reset();
            }
            else if(p2won())
            {
                showWin(2);
                Reset();
            }
            
        }
        else
        {
            showMessage();
        }
    }//GEN-LAST:event_b8ActionPerformed

    private void b9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b9ActionPerformed
        if(buttonused[8]==0)
        {
            if(turn%2==0)
            {
                b9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/XO/X Small.jpeg")));
                buttonused[8]=1;
                p1won[8]=1;
            }
            else
            {
                b9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/XO/O small.jpeg")));
                buttonused[8]=1;
                p2won[8]=1;
            }
            turn++;
            if(p1won())
            {
                showWin(1);
                Reset();
                
            }
            else if(p2won())
            {
                showWin(2);
                Reset();
            }
        }
        else
        {
            showMessage();
        }
    }//GEN-LAST:event_b9ActionPerformed

    private void p2_nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p2_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_p2_nameActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        b1.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b2.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b3.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b4.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b5.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b6.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b7.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b8.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b9.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        for(int i=0;i<9;i++)
        {
            p1won[i]=0;
            p2won[i]=0;
            buttonused[i]=0;
        }
        p1_score = 0;
        p2_score = 0;
        p1_score_label.setText(""+p1_score);
        p2_score_label.setText(""+p2_score);
    }//GEN-LAST:event_jButton1ActionPerformed
    public void Reset()
    {
        b1.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b2.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b3.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b4.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b5.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b6.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b7.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b8.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b9.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        for(int i=0;i<9;i++)
        {
            p1won[i]=0;
            p2won[i]=0;
            buttonused[i]=0;
        }
        
    }
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        b1.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b2.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b3.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b4.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b5.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b6.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b7.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b8.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        b9.setIcon(new javax.swing.ImageIcon(getClass().getResource("")));
        for(int i=0;i<9;i++)
        {
            p1won[i]=0;
            p2won[i]=0;
            buttonused[i]=0;
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if((p1_name.getText().equals(null))&&(p2_name.getText().equals(null)))
        {
            System.exit(0);
        }
        else
        {
            main_panel.setVisible(true);
            name1 = p1_name.getText().toUpperCase();
            name2 = p2_name.getText().toUpperCase();
            
            name1_label.setText(name1);
            name2_label.setText(name2);
            
            p1label.setText(name1+" = X");
            p2label.setText(name2+" = O");
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        if(JOptionPane.showConfirmDialog(this,"Are you surely going to quit","TIC TAC TOE",
                JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION)
        {
            if(p1_score==p2_score)
            {
                JOptionPane.showMessageDialog(this,"!*Match Draw*!");
            }
            else if(p1_score>p2_score)
            {
                JOptionPane.showMessageDialog(this,"!* "+name1.toUpperCase()+" WON THE MATCH*!");
            }
            else
            {
                JOptionPane.showMessageDialog(this,"!* "+name2.toUpperCase()+" WON THE MATCH*!");
            }
            dispose();
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jPanel1ComponentHidden(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_jPanel1ComponentHidden
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel1ComponentHidden

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        new Manual1().setVisible(true);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MouseEntered
        help_msg.setText("help");
    }//GEN-LAST:event_jButton5MouseEntered

    private void jButton5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MouseExited
        help_msg.setText("");
    }//GEN-LAST:event_jButton5MouseExited

    private void jButton4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseEntered
        exit_msg.setText("Quit");
    }//GEN-LAST:event_jButton4MouseEntered

    private void jButton4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseExited
        exit_msg.setText("");
    }//GEN-LAST:event_jButton4MouseExited

    private void jButton2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseEntered
        play_again_msg.setText("Resets the board");
    }//GEN-LAST:event_jButton2MouseEntered

    private void jButton2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseExited
        play_again_msg.setText("");

    }//GEN-LAST:event_jButton2MouseExited

    private void jButton1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseEntered
        reset_msg.setText("Resets score and board");
    }//GEN-LAST:event_jButton1MouseEntered

    private void jButton1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseExited
        reset_msg.setText("");
    }//GEN-LAST:event_jButton1MouseExited

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TicTacToe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TicTacToe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TicTacToe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TicTacToe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TicTacToe().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b1;
    private javax.swing.JButton b2;
    private javax.swing.JButton b3;
    private javax.swing.JButton b4;
    private javax.swing.JButton b5;
    private javax.swing.JButton b6;
    private javax.swing.JButton b7;
    private javax.swing.JButton b8;
    private javax.swing.JButton b9;
    private javax.swing.JLabel exit_msg;
    private javax.swing.JLabel help_msg;
    private javax.swing.JButton jButton1;
    public javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    public javax.swing.JPanel main_panel;
    private javax.swing.JLabel name1_label;
    private javax.swing.JLabel name1_label1;
    private javax.swing.JLabel name2_label;
    private javax.swing.JLabel name2_label1;
    private javax.swing.JTextField p1_name;
    private javax.swing.JLabel p1_score_label;
    private javax.swing.JLabel p1label;
    private javax.swing.JTextField p2_name;
    private javax.swing.JLabel p2_score_label;
    private javax.swing.JLabel p2label;
    private javax.swing.JLabel play_again_msg;
    private javax.swing.JLabel reset_msg;
    public javax.swing.JPanel score_panel;
    public javax.swing.JPanel ttt_panel;
    // End of variables declaration//GEN-END:variables
}
